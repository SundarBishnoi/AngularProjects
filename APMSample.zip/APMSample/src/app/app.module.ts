import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SalesreportComponent } from './sales/salesreport.component';
import { ProductlistComponent } from './products/productlist.component';
import { ConvertToSpacePipe } from './shared/convert-to-space.pipe';
import {StarComponent} from './shared/star.component';
import {HttpClientModule} from '@angular/common/http';
import { ProductService } from './services/product.service';
import { WelcomeComponent } from './welcome/welcome.component';
import { RouterModule } from '@angular/router';
import { ProductdetailsComponent } from './products/productdetails/productdetails.component';
import { AddproductComponent } from './products/addproduct/addproduct.component';
import { SearchComponent } from './products/search/search.component';

@NgModule({
  declarations: [
    AppComponent,
    SalesreportComponent,
    ProductlistComponent,
    ConvertToSpacePipe,
    StarComponent,
    WelcomeComponent,
    ProductdetailsComponent,
    AddproductComponent,
    SearchComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'products', component: ProductlistComponent},
      {path:'welcome',component:WelcomeComponent},
      {path:'', redirectTo:'welcome',pathMatch:'full'},
      { path: 'product/:id',component:ProductdetailsComponent},
      {path:'products/addproduct', component:AddproductComponent}
    ]),
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule {}