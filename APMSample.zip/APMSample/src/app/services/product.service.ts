import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';

import {Observer, observable,throwError} from 'rxjs';
import { Observable } from 'rxjs';
import {map, catchError} from 'rxjs/operators';
import { pipe } from '@angular/core/src/render3';
import { Product } from '../products/product/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  /** private productUrl:string = './api/product/products.json';*/
  private productDataUrl:string= '/productsData/productsList.json';
  constructor(private httpClient:HttpClient) {}

  getAllProductsDetails():Observable<Product[]>{
    return this.httpClient.get<Product[]>("http://localhost:2222/onlineshop/allProductDetails").pipe(catchError(this.handleError));
  }
  public getProductDetails(productId:number):Observable<Product>{
    let params = new HttpParams();
    params = params.set('productId', productId.toString());
    return this.httpClient.get<Product>("http://localhost:2222/onlineshop/productDetails",{params: params}).pipe(catchError(this.handleError));
  }
  public sendProductDetails(productId:number):Observable<Product>{
    let params = new HttpParams();
    params = params.set('productId',productId.toString());
    return this.httpClient.post<Product>("http://localhost:2222/onlineshop/acceptProductDetails",{params:params}).pipe(catchError(this.handleError));
  }
  private handleError(error: any){
    if(error instanceof ErrorEvent){
      console.error(`1 An ErrorEvent occured:`, error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was: ${error.message}`);
    }
    else if(error instanceof TypeError){
      console.error(`3 TypeError has occured ${error.message}, body was ${error.stack}`)
      return throwError(`TypeError has occured ${error.message}, body was ${error.stack}`)
    }
  }
}