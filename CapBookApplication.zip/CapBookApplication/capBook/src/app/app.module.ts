import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './account/registration/registration.component';
import { RouterModule } from '@angular/router';
import { AccountService } from './services/account.service';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './account/login/login.component';
import { ProfileComponent } from './account/profile/profile.component';
import { HomeComponent } from './account/home/home.component';
import { AlertComponent } from './account/alert/alert.component';
import { HttpModule } from '@angular/http';
import { SidemenuComponent } from './account/sidemenu/sidemenu.component';
import { InfopageComponent } from './account/infopage/infopage.component';
import { PhotosComponent } from './account/photos/photos.component';
import { ChangepasswordComponent } from './account/changepassword/changepassword.component';
import { LogoutComponent } from './account/logout/logout.component';
import { NavbarComponent } from './account/navbar/navbar.component';
import { StatusComponent } from './account/status/status.component';
import { FriendrequestsComponent } from './account/friendrequests/friendrequests.component';
import { WallComponent } from './account/wall/wall.component';
import { ForgotpasswordComponent } from './account/forgotpassword/forgotpassword.component';
import { SearchComponent } from './account/search/search.component';
import { RequestsuccessComponent } from './account/requestsuccess/requestsuccess.component';
import { UploadformComponent } from './account/uploadform/uploadform.component';
import { FriendsComponent } from './account/friends/friends.component';
import { FriendprofileComponent } from './account/friendprofile/friendprofile.component';


@NgModule({
  declarations: [
   
    AppComponent,
    RegistrationComponent,
    LoginComponent,
    ProfileComponent,
    HomeComponent,
    AlertComponent,
    SidemenuComponent,
    InfopageComponent,
    PhotosComponent,
    ChangepasswordComponent,
    LogoutComponent,
    NavbarComponent,
    StatusComponent,
    FriendrequestsComponent,
    WallComponent,
    ForgotpasswordComponent,
    SearchComponent,
    RequestsuccessComponent,
    UploadformComponent,
    FriendsComponent,
    FriendprofileComponent,
  ],

  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot([
      {path: 'registration', component: RegistrationComponent},
      {path: 'login', component: LoginComponent}, 
      {path: 'home', component: HomeComponent},
      {path: 'infopage', component: InfopageComponent},  
      {path: 'friendprofile/:id', component: FriendprofileComponent}, 
      {path: 'search', component: SearchComponent}, 
      {path: 'requestsuccess/:id', component: RequestsuccessComponent}, 
      {path: 'friendrequests', component: FriendrequestsComponent},
      {path: 'photos', component: PhotosComponent},
      {path: 'changepassword', component: ChangepasswordComponent},
      {path: 'status', component: StatusComponent},
      {path: 'wall', component: WallComponent},
      {path: 'forgotpassword', component: ForgotpasswordComponent},
      {path: 'uploadform', component: UploadformComponent},
      {path: 'friends', component: FriendsComponent},
      {path: '',redirectTo: 'home', pathMatch: 'full'},
      {path: '**',redirectTo: '/home',pathMatch: 'full'}
    ]),
  ],
  providers: [AccountService],
  bootstrap: [AppComponent]
})
export class AppModule { }
