var capBook = angular.module('capBook', ['ngRoute']);

capBook.config(function($routeProvider){
    $routeProvider
    .when('/', {templateUrl: './home.component.html', controller:'mainController'})
    .when('/login', {templateUrl:'./login.component.html', controller:'loginController'})
});

capBook.controller('mainController', function($scope) {

    // create a message to display in our view
    //$scope.message = 'Everyone come and see how good I look!';
});
capBook.controller('loginController', function($scope) {

    // create a message to display in our view
    //$scope.message = 'Everyone come and see how good I look!';
});