import { Injectable } from '@angular/core';
import { throwError, Observable } from 'rxjs';
import { HttpClient,HttpErrorResponse,HttpHeaders, HttpParams, HttpEvent, HttpRequest} from '@angular/common/http';
import { User } from '../account/user';
import { catchError } from 'rxjs/operators'
import { Status } from '../account/status';
import { Photos } from '../account/photos';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  private headers = new HttpHeaders({'Content-Type': 'application/json'});
  userId:string;
  id:string;

  constructor(private httpClient:HttpClient) { }

  public registerUser(user:User): Observable<any>{
    return this.httpClient.post("http://localhost:4444/openAccount", user, {headers:this.headers});
  }

  public loginUser(emailId:string,password:string): Observable<any>{
    let params = new HttpParams();
    params = params.set('emailId', emailId);
    params = params.set('password', password);
    
    return this.httpClient.get<any>("http://localhost:4444/getUserDetails",{params:params}).pipe(catchError(this.handleError));
  }

  public getUserDetails():Observable<any>{
    let params = new HttpParams();
    params = params.set('userId', this.userId);
    return this.httpClient.get<any>("http://localhost:4444/getDetails",{params:params}).pipe(catchError(this.handleError));
  }

  public getAllUserDetails():Observable<User[]>{
    let params = new HttpParams();
    params = params.set('userId', this.userId);
    return this.httpClient.get<User[]>("http://localhost:4444/getAllUserDetails",{params:params}).pipe(catchError(this.handleError));
  }

  public sendRequest(uId:string):Observable<boolean>{
    let params= new HttpParams();
    params = params.set('userOneId',this.userId);
    console.log("!! "+ this.userId);
    params = params.set('userTwoId', uId);
    console.log("!@ "+uId);
    return this.httpClient.get<boolean>("http://localhost:4444/sendRequest",{params : params}).pipe(catchError(this.handleError));
  }

  public getRequestList():Observable<User[]>{
    let params = new HttpParams();
    params = params.set('userTwoId', this.userId);
    return this.httpClient.get<User[]>("http://localhost:4444/getRequestList",{params : params}).pipe(catchError(this.handleError));
  }
  public updateRequest(status:number,uid:string):Observable<boolean>{
    console.log("service ts "+uid);
    console.log("service ts "+status);
    let params = new HttpParams();
    params = params.set('userOneId',uid);
    params = params.set('userTwoId',this.userId);
    params = params.set('status',status.toString());
    return this.httpClient.get<boolean>("http://localhost:4444/updateRequest",{params : params}).pipe(catchError(this.handleError));
  }

  pushFileToStorage(file: File): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    formdata.append('emailId',this.userId);
    const req = new HttpRequest('POST', 'http://localhost:4444/uploadphoto', formdata, {
      reportProgress: true,
      responseType: 'text'
    });
    return this.httpClient.request(req);
  }
  getAllPhotos(): Observable<Photos> {
    let params = new HttpParams();
    params = params.set('emailId',this.userId);
    return this.httpClient.get<Photos>('http://localhost:4444/retrievephoto',{params : params}).pipe(catchError(this.handleError));
  }
 
  public setUserId(userId:string):void{
    this.userId=userId;
  }
  public getUserId():string{
    return this.userId;
  }
  public dropUserId():void{
    this.userId="null";
  }

  public changePassword(oldPassword:string,newPassword:string):Observable<boolean>{
    let params=new HttpParams();
    params = params.set('userId',this.userId);
    params = params.set('oldPassword', oldPassword);
    params = params.set('newPassword', newPassword);
    return this.httpClient.get<boolean>("http://localhost:4444/changePassword",{params:params}).pipe(catchError(this.handleError));
  }

  public postStatus(status:string):Observable<boolean>{
    let params=new HttpParams();
    params = params.set('userId',this.userId);
    params = params.set('status', status);
    return this.httpClient.get<boolean>("http://localhost:4444/status", {params:params}).pipe(catchError(this.handleError));
  }
  public getAllStatus():Observable<Status[]>{
    let params=new HttpParams();
    params = params.set('userId',this.userId);
    return this.httpClient.get<Status[]>("http://localhost:4444/getStatus",{params:params}).pipe(catchError(this.handleError));
  }

  public forgotPassword(emailId:string,securityAnswer:string,newPassword:string): Observable<any>{
    let params = new HttpParams();
    params = params.set('emailId',emailId);    
    params = params.set('securityAnswer',securityAnswer);
    params =  params.set('newPassword',newPassword);
    return this.httpClient.get<any>("http://localhost:4444/forgotPassword",{params:params}).pipe(catchError(this.handleError));
  }
  public getFriends(): Observable<User[]>{
    let params = new HttpParams();
    params = params.set('userId',this.userId);
    return this.httpClient.get<User[]>("http://localhost:4444/getFriendList",{params:params}).pipe(catchError(this.handleError));
  }

  public getFriendProfile(uid:string):Observable<User>{
    let params=new HttpParams();
    params = params.set('userId',uid);
    return this.httpClient.get<any>("http://localhost:4444/getDetails",{params:params}).pipe(catchError(this.handleError)); 
  }

  public getFriendStatus(uid:string):Observable<Status[]>{
    let params=new HttpParams();
    params = params.set('userId',uid);
    return this.httpClient.get<Status[]>("http://localhost:4444/getStatus",{params:params}).pipe(catchError(this.handleError));
  }

  public getFriendPhoto(uid:string): Observable<Photos> {
    let params = new HttpParams();
    params = params.set('emailId',uid);
    return this.httpClient.get<Photos>('http://localhost:4444/retrievephoto',{params : params}).pipe(catchError(this.handleError));
  }

  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error('1 An ErrorEvent occurred:',error.error.message);
      return throwError(error.error.message);
    } else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was: ${error.message}`);
    } else if(error instanceof TypeError){
      console.error(`3 TypeError has occurred ${error.message}, body was ${error.stack}`);
      return throwError(`TypeError has occurred ${error.message}, body was ${error.stack}`);
    }
  }
}
