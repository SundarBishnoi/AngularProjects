import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';
import { first } from 'rxjs/operators';
import { Status } from '../status';

@Component({
  selector: 'app-wall',
  templateUrl: './wall.component.html',
  styleUrls: ['./wall.component.css']
})
export class WallComponent implements OnInit {
  status:Status[];
  statusList:Status[];
  message:string;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private accountService:AccountService) { }

  ngOnInit() {
    this.accountService.getAllStatus().pipe(first()).subscribe(
      data=>{
        this.status=data;
        this.statusList=this.status;
      },
      error=>{
        this.message="No posts yet."
      });
  }

}
