export interface Status{
    statusId:number;
    text:string;
    statusDate:string;   
}