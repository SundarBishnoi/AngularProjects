import { Component, OnInit } from '@angular/core';
import { AccountService } from 'src/app/services/account.service';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../user';
import { Photos } from '../photos';

@Component({
  selector: 'app-infopage',
  templateUrl: './infopage.component.html',
  styleUrls: ['./infopage.component.css']
})
export class InfopageComponent implements OnInit {
  user:User;
  fileData: Photos;
  byteData: Blob;
  male:boolean=false;
  female:boolean=false;
  dp:boolean=false;

  constructor(private route: ActivatedRoute, private router: Router, private accountService:AccountService) { }

  ngOnInit() {
    //const id=this.route.snapshot.paramMap.get('id');
    //const uId= +id;
    this.accountService.getUserDetails().subscribe(
      user=>{       
        this.user=user;
        if(this.user.gender==="male")
          this.male=true;
        else 
        this.female=true;
      },
      errorMessage=>{
        //this.errorMessage=errorMessage;
      }
    );

    this.accountService.getAllPhotos().subscribe(
      tempFile => {
        
          this.fileData=tempFile;  
          this.byteData=this.fileData.data;        
          this.dp=true;
          this.male=false;
          this.female=false;
    },
    error => {
      //this.error = error;
    }
    );

    
  }

}