import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';

@Component({
  selector: 'app-friendrequests',
  templateUrl: './friendrequests.component.html',
  styleUrls: ['./friendrequests.component.css']
})
export class FriendrequestsComponent implements OnInit {

  user: User;
  errorMessage: string;
  successMessage: string;
  friendList:User[];
  friends:User[];
  uid:string;
  reject:number=0;
  accept:number=0;

  constructor(private route:ActivatedRoute,private router:Router,private accountService:AccountService) { }
  
  ngOnInit() {
  this.accountService.getRequestList().subscribe(
    users=>{
      this.friends=users;
      this.friendList=this.friends;
    },
    error=>{
      this.errorMessage="error";
    }
  )
  

  }

  public acceptRequest(uid:string):void{     
    if (this.reject!==1){
      this.accountService.updateRequest(1,uid).subscribe(
        data=>{
          this.accept=1;
          this.successMessage="Friend request accepted."
          //this.acceptButton=false;
          //this.rejectButton=false;
        },
        error=>{
          this.errorMessage="Action cannot be performed.";
        });
    }
    else
      this.errorMessage="Action cannot be performed.";   
    
  }

  public rejectRequest(uid:string):void{
    if(this.accept!==1){
      this.accountService.updateRequest(2,uid).subscribe(
        data=>{
          this.reject=1;
          this.successMessage="Friend request declined."
        },
        error=>{
          this.errorMessage="Action cannot be performed.";
        });
    }
    else
      this.errorMessage="Action cannot be performed.";    
  }

}
