import { Component, OnInit } from '@angular/core';
import { AccountService } from 'src/app/services/account.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from '../user';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
    changePasswordForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    errorMessage:string;
    successMessage:string;
    sessionId:string;
    userId:string;
    user:User;
  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private accountService:AccountService) { }

  ngOnInit() {
    this.changePasswordForm = this.formBuilder.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', Validators.required]
    });
  // get return url from route parameters or default to '/'
  //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }
  get f() { return this.changePasswordForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.changePasswordForm.invalid) {
        return;
    }
    //this.loading = true;
    console.log(this.f.oldPassword.value);
    console.log(this.f.newPassword.value);
    this.accountService.changePassword(this.f.oldPassword.value,this.f.newPassword.value).subscribe(
      data =>{
        this.successMessage="Password changed successfully";
      },
      error =>{
        this.errorMessage="Incorrect Password";
      });
    
  }

}
