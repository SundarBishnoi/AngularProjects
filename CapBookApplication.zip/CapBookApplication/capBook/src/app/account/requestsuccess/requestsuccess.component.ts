import { Component, OnInit } from '@angular/core';
import { AccountService } from 'src/app/services/account.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-requestsuccess',
  templateUrl: './requestsuccess.component.html',
  styleUrls: ['./requestsuccess.component.css']
})
export class RequestsuccessComponent implements OnInit {

  constructor(private route:ActivatedRoute, private router:Router, private accountService:AccountService) { }
  successMessage:string;
  errorMessage:string;
  ngOnInit() {
    let uid:any =this.route.snapshot.paramMap.get('id');
    //const userId= +id;
    console.log("%%%%"+uid);
    this.accountService.sendRequest(uid).subscribe(
    data=>{
      this.successMessage="Friend request sent."
    },
    error=>{
      this.errorMessage="Friend request already pending.";
    }
  );

  }
  navigateBack(){
    this.router.navigate(['/search']);
  }

}
