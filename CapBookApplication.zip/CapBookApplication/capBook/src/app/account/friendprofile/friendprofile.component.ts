import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';
import { User } from '../user';
import { Status } from '../status';
import { Photos } from '../photos';

@Component({
  selector: 'app-friendprofile',
  templateUrl: './friendprofile.component.html',
  styleUrls: ['./friendprofile.component.css']
})
export class FriendprofileComponent implements OnInit {
  user:User;
  status:Status[];
  statusList:Status[];
  message:string;
  fileData: Photos;
  byteData: Blob;
  male:boolean=false;
  female:boolean=false;
  dp:boolean=false;


  constructor(private route:ActivatedRoute, private router:Router, private accountService:AccountService) { }

  ngOnInit() {
    let uid:any =this.route.snapshot.paramMap.get('id');
    this.accountService.getFriendProfile(uid).subscribe(
      data=>{
        this.user=data;
      },
      error=>{

      });

      this.accountService.getFriendPhoto(uid).subscribe(
        tempFile => {
          
            this.fileData=tempFile;  
            this.byteData=this.fileData.data;        
            this.dp=true;
            this.male=false;
            this.female=false;
      },
      error => {
        //this.error = error;
      }
      );

      this.accountService.getFriendStatus(uid).subscribe(
        data=>{
          this.status=data;
          this.statusList=this.status;
        },
        error=>{
          this.message="No posts yet."
        });
  }

}
