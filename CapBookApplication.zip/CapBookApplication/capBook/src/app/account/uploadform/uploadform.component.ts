import { Component, OnInit } from '@angular/core';
import { AccountService } from 'src/app/services/account.service';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Photos } from '../photos';

@Component({
  selector: 'app-uploadform',
  templateUrl: './uploadform.component.html',
  styleUrls: ['./uploadform.component.css']
})
export class UploadformComponent implements OnInit {

  imageUrl = '/assets/images/img11.png';
  fileToUpload: File = null;
  selectedFiles: FileList;
  // retrieveFiles: Image[];
  currentFileUpload: File;
  fileData: Photos;
  progress: { percentage: number } = { percentage: 0 };
  byteData: Blob;

  error: string;

  constructor(private accountServices: AccountService) { }

  ngOnInit() {
  }

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

  handleFileInput(file: FileList) {
  this.fileToUpload = file.item(0);
  const reader = new FileReader();
  reader.onload = (event: any) => {
    this.imageUrl = event.target.result;
  };
  reader.readAsDataURL(this.fileToUpload);
  }

  upload() {
    this.progress.percentage = 0;
    const fd = new FormData();

    fd.append('image', this.fileToUpload, this.fileToUpload.name);
    this.accountServices.pushFileToStorage(this.fileToUpload).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        this.progress.percentage = Math.round(100 * event.loaded / event.total);
      } else if (event instanceof HttpResponse) {
        console.log('File is completely uploaded!');
      }
    });

    this.selectedFiles = undefined;
  }

}
