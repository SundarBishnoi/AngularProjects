export interface User{
    //userId:number;
    emailId: string;
    password: string;
    firstName: string;
    lastName: string;
    age:number;
    dateOfBirth:string;
    gender: string;   
    securityAnswer:string; 
}