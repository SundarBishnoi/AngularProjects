import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {
  statusForm:FormGroup;
  submitted = false;
  errorMessage:string;
  successMessage:string;

  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private accountService:AccountService) { }

  ngOnInit() {
    this.statusForm = this.formBuilder.group({
      status: ['', Validators.required]
  });
  // get return url from route parameters or default to '/'
  //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }
  get f() { return this.statusForm.controls; }
  onSubmit(){
    this.submitted = true;
        if (this.statusForm.invalid) {
            return;
        }
    this.accountService.postStatus(this.f.status.value).pipe(first()).subscribe(
      data =>{
        this.successMessage="Status posted successfully";
        this.router.navigate(['/status']);
      },
      error =>{
        this.errorMessage="Error";
        this.router.navigate(['/status']);
      });
  }

}
