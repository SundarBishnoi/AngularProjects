import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';
import { User } from '../User';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AlertService } from 'src/app/services/alert.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registerForm:FormGroup;
  loading=false;
  submitted=false;
  returnUrl: string;
  emailPattern="^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";

  constructor(private route:ActivatedRoute, private router:Router,private accountService:AccountService,
    private formBuilder:FormBuilder,private alertService:AlertService) {}


  ngOnInit() {
    this.registerForm=this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      emailId: ['', Validators.required], //Validators.pattern(this.emailPattern)]],
      age: ['', Validators.required],
      gender: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      password: ['', Validators.required],
      securityAnswer: ['', Validators.required]
    });
    //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }
  
  get f(){return this.registerForm.controls;}

  onSubmit(){
    this.submitted=true;
      if(this.registerForm.invalid){
       //return;
      
    this.loading=true;
    this.accountService.registerUser(this.registerForm.value).pipe(first())
      .subscribe(
        data => {
            //this.alertService.success('Registration successful', true);
            this.router.navigate(['/login']);
        },
        error => {
            //this.alertService.error(error);
            //this.loading = false;
            this.router.navigate(['/registration']);
        });

      }
      
  }

}