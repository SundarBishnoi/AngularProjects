import { Component, OnInit } from '@angular/core';
import { AccountService } from 'src/app/services/account.service';
import { User } from '../user';

@Component({
  selector: 'app-friends',
  templateUrl: './friends.component.html',
  styleUrls: ['./friends.component.css']
})
export class FriendsComponent implements OnInit {
  users:User[];
  userList:User[];
  constructor(private accountService:AccountService) {}

  ngOnInit() {
    this.accountService.getFriends().subscribe(
      data=>{
        this.userList=data;
        this.users=this.userList;
      },
      error=>{

      });
  }

}
