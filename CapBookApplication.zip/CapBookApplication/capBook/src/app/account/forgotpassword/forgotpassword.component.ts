import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
    forgotPasswordForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    errorMessage:string;

  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private accountService:AccountService) { }

  ngOnInit() {
    this.forgotPasswordForm = this.formBuilder.group({
      emailId: ['', Validators.required],
      securityAnswer:['', Validators.required],
      newPassword: ['', Validators.required]
  });
  // get return url from route parameters or default to '/'
  //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  get f() { return this.forgotPasswordForm.controls; }

  onSubmit(){
    this.submitted=true;
      if(this.f.invalid){
        return;
      }
    this.loading=true;
 
    this.accountService.forgotPassword(this.f.emailId.value,this.f.securityAnswer.value,this.f.newPassword.value).pipe(first())
      .subscribe(
        data => {
            //this.alertService.success('Password successfully updated.', true);
            this.router.navigate(['/login']);
        },
        error => {
            //this.alertService.error(error);
            this.errorMessage="Incorrect answer";
            this.router.navigate(['/forgotpassword']);
        });
  }
  


}
