import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  error:string
    friendList:User[];
    friends:User[];
    user:User;
    errorMessage:string;


  constructor(private route: ActivatedRoute,
    private router: Router,
    private accountService:AccountService) { }

  ngOnInit() {
    this.accountService.getAllUserDetails().subscribe(
      users=>{
        this.friends=users;
        this.friendList=this.friends;
        
      },
      error=>{
        //this.error=error;
      }
    );
  }

}
